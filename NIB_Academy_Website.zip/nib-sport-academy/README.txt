NIB SPORT ACADEMY — WEBSITE FILES

EDITING IS EASY
- Open index.html to change text, program details, fees and contact information.
- Open style.css to change colours, spacing, fonts and layout.
- Open script.js for the mobile navigation behaviour.
- You can edit these files with VS Code, Notepad++ or even Notepad.

PHOTOSHOOT UPDATE (IMPORTANT)
The current website uses generic football photos from Unsplash as temporary visuals. They are NOT photos of NIB Sport Academy. After the academy photoshoot:
1. Put the selected photos inside the assets folder.
2. In index.html, find the comments marked PHOTO AREA and PROGRAM PHOTOS.
3. Replace each temporary https://images.unsplash.com/... image URL with a local path, for example assets/team-training.jpg.
4. For the big hero photo, open style.css and find .hero-photo. Replace the Unsplash URL there with url("assets/academy-team.jpg").
5. Save, refresh index.html in your browser, then upload the updated folder to Netlify Drop.

SUGGESTED PHOTOSHOOT SHOTS
- Team group photo (hero section)
- Coach giving instructions
- Players doing drills
- Match/action shot
- Team huddle or celebration
Use clear, high-resolution photos and get permission from parents/guardians before publishing identifiable photos of children.

NETLIFY DEPLOY
1. Extract the ZIP.
2. Open https://app.netlify.com/drop
3. Drag the extracted nib-sport-academy folder onto the page.
4. To update later, edit the same files and upload the updated folder again.

BEFORE PUBLICATION
Please confirm the academy name, fees, phone numbers, email and exact training venue with the coach. Fee details were transcribed from supplied material and are marked for confirmation.

No online registration form or gallery is included, as requested.
